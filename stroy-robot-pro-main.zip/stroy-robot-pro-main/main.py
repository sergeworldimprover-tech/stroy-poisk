"""
╔══════════════════════════════════════════════════════════╗
║          СТРОЙ-РОБОТ 63 — КОНФИГУРАЦИЯ ПРОЕКТА          ║
║  Все настройки здесь. Меняй только этот блок при        ║
║  переносе на Render / Railway / любой другой сервер.    ║
╚══════════════════════════════════════════════════════════╝
"""

import os
import re
import datetime
import pandas as pd
from flask import Flask, send_file, jsonify, render_template_string

# ─── НАСТРОЙКИ (единственное место для правок) ────────────────────────────────

# Корневая папка для поиска файлов. При деплое замени на абсолютный путь.
# "/" = весь сервер, "." = только папка рядом со скриптом.
SEARCH_ROOT = os.environ.get("SEARCH_ROOT", os.path.dirname(os.path.abspath(__file__)))

# Ключевые слова для автопоиска нужных файлов (регистр не важен)
FILE_KEYWORDS = {
    "samara":  ["01_Baza", "Baza_Postavshikov", "Samara", "база_самара", "postavshik"],
    "top20":   ["02_Katalog", "Katalog_Material", "TOP20", "Топ20", "каталог"],
}

# Колонка-ключ для "умного" объединения (попробует найти автоматически, если пусто)
JOIN_COLUMN_HINT = os.environ.get("JOIN_COLUMN", "")

# Куда сохранять итоговый отчёт
OUTPUT_FILENAME = os.environ.get("OUTPUT_FILENAME", "FINAL_OTCHET.xlsx")

# Максимальная глубина поиска по дереву папок (защита от зависания)
MAX_SEARCH_DEPTH = int(os.environ.get("MAX_SEARCH_DEPTH", "6"))

# Порт Flask
PORT = int(os.environ.get("PORT", 25820))

# ─── КОНЕЦ НАСТРОЕК ───────────────────────────────────────────────────────────

app = Flask(__name__)

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
OUTPUT_PATH = os.path.join(BASE_DIR, OUTPUT_FILENAME)


# ─── АВТОНОМНЫЙ ПОИСК ФАЙЛОВ ─────────────────────────────────────────────────

def scan_for_file(keywords: list[str], root: str = SEARCH_ROOT) -> str | None:
    """
    Рекурсивно сканирует дерево папок от `root` и возвращает первый .xlsx/.xls
    файл, в имени которого встречается одно из ключевых слов (без учёта регистра).
    """
    root = os.path.abspath(root)
    for dirpath, dirnames, filenames in os.walk(root):
        # Ограничиваем глубину поиска
        depth = dirpath[len(root):].count(os.sep)
        if depth >= MAX_SEARCH_DEPTH:
            dirnames.clear()
            continue
        # Пропускаем служебные папки
        dirnames[:] = [d for d in dirnames if not d.startswith((".", "node_modules", "__pycache__", "dist"))]
        for fname in filenames:
            if not fname.lower().endswith((".xlsx", ".xls")):
                continue
            for kw in keywords:
                if kw.lower() in fname.lower():
                    return os.path.join(dirpath, fname)
    return None


def find_files() -> dict:
    """Возвращает словарь {role: path_or_None} для всех нужных файлов."""
    return {
        "samara": scan_for_file(FILE_KEYWORDS["samara"]),
        "top20":  scan_for_file(FILE_KEYWORDS["top20"]),
    }


# ─── УМНОЕ ОБЪЕДИНЕНИЕ ДАННЫХ ─────────────────────────────────────────────────

def _normalize_series(s: pd.Series) -> pd.Series:
    """Приводит строковую колонку к нижнему регистру без лишних пробелов."""
    return s.astype(str).str.strip().str.lower().str.replace(r"\s+", " ", regex=True)


def smart_merge(df_top: pd.DataFrame, df_base: pd.DataFrame) -> pd.DataFrame:
    """
    Интеллектуальное объединение:
    1. Ищет общие колонки.
    2. Нормализует их значения (регистр, пробелы) перед сопоставлением.
    3. Если нет общих колонок — объединяет строки вертикально.
    """
    # Найти колонки для объединения
    if JOIN_COLUMN_HINT and JOIN_COLUMN_HINT in df_top.columns and JOIN_COLUMN_HINT in df_base.columns:
        join_cols = [JOIN_COLUMN_HINT]
    else:
        join_cols = [c for c in df_top.columns if c in df_base.columns]

    if not join_cols:
        # Нет общих колонок — склеиваем вертикально
        return pd.concat([df_top, df_base], axis=0, ignore_index=True)

    # Нормализуем ключевые колонки во временных копиях
    top_work = df_top.copy()
    base_work = df_base.copy()
    tmp_suffix = "__norm__"

    for col in join_cols:
        top_work[col + tmp_suffix] = _normalize_series(top_work[col])
        base_work[col + tmp_suffix] = _normalize_series(base_work[col])

    norm_cols = [c + tmp_suffix for c in join_cols]

    merged = pd.merge(
        top_work,
        base_work,
        left_on=norm_cols,
        right_on=norm_cols,
        how="left",
        suffixes=("", "_база"),
    )

    # Убираем служебные колонки нормализации
    merged.drop(columns=[c for c in merged.columns if c.endswith(tmp_suffix)], inplace=True)

    return merged


# ─── HTML-ШАБЛОН СТРАНИЦЫ ─────────────────────────────────────────────────────

PAGE = """<!DOCTYPE html>
<html lang="ru">
<head>
  <meta charset="utf-8">
  <title>Строй-Робот 63 — Снабжение</title>
  <style>
    *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
    body {
      font-family: 'Segoe UI', Arial, sans-serif;
      background: linear-gradient(135deg, #e8ecf5 0%, #dde4f0 100%);
      min-height: 100vh;
      display: flex; flex-direction: column;
      align-items: center; justify-content: center;
      padding: 24px;
    }

    /* ── статус-бар ── */
    .statusbar {
      width: 100%; max-width: 520px;
      display: flex; align-items: center; justify-content: space-between;
      background: #fff; border-radius: 10px;
      padding: 9px 16px; margin-bottom: 14px;
      box-shadow: 0 2px 10px rgba(0,0,0,.07);
      font-size: 12px; color: #555;
    }
    .statusbar .label { font-weight: 600; color: #333; }
    .statusbar .pulse {
      width: 8px; height: 8px; border-radius: 50%;
      background: #28a745; margin-right: 6px; display: inline-block;
      animation: pulse 2s infinite;
    }
    @keyframes pulse {
      0%,100% { opacity: 1; } 50% { opacity: .35; }
    }
    .statusbar .ts { color: #888; }

    /* ── карточка ── */
    .card {
      background: #fff; border-radius: 20px;
      padding: 44px 48px; max-width: 520px; width: 100%;
      box-shadow: 0 12px 44px rgba(0,0,0,.12);
      text-align: center;
    }
    .icon { font-size: 52px; margin-bottom: 10px; }
    h1 { font-size: 23px; color: #1a1a2e; font-weight: 800; margin-bottom: 6px; }
    .desc { color: #666; font-size: 14px; margin-bottom: 26px; line-height: 1.65; }

    /* ── список файлов ── */
    .files {
      background: #f5f7fc; border: 1px solid #dce2f0;
      border-radius: 14px; padding: 16px 20px;
      margin-bottom: 26px; text-align: left;
    }
    .files-title {
      font-size: 10.5px; font-weight: 700; color: #999;
      text-transform: uppercase; letter-spacing: .8px; margin-bottom: 11px;
    }
    .file-row {
      display: flex; align-items: flex-start; gap: 9px;
      font-size: 13px; color: #333; padding: 5px 0;
      border-bottom: 1px solid #eaedf5;
    }
    .file-row:last-child { border-bottom: none; }
    .dot {
      width: 8px; height: 8px; border-radius: 50%;
      margin-top: 4px; flex-shrink: 0;
    }
    .dot.ok  { background: #28a745; }
    .dot.err { background: #dc3545; }
    .file-row .name { font-weight: 700; font-size: 12px; color: #444; }
    .file-row .path { font-size: 11px; color: #aaa; margin-top: 1px; word-break: break-all; }

    /* ── кнопка ── */
    .btn {
      width: 100%; padding: 19px;
      background: linear-gradient(135deg, #0062ff 0%, #0041cc 100%);
      color: #fff; font-size: 18px; font-weight: 800;
      border: none; border-radius: 14px; cursor: pointer;
      letter-spacing: .6px; box-shadow: 0 6px 20px rgba(0,98,255,.35);
      transition: opacity .2s, transform .15s, box-shadow .2s;
    }
    .btn:hover  { opacity: .92; transform: translateY(-2px); box-shadow: 0 10px 28px rgba(0,98,255,.4); }
    .btn:active { transform: translateY(0); box-shadow: 0 4px 14px rgba(0,98,255,.3); }
    .btn:disabled { opacity: .55; cursor: not-allowed; transform: none; box-shadow: none; }

    /* ── результат ── */
    #result {
      margin-top: 20px; padding: 16px 20px; border-radius: 13px;
      font-size: 14px; display: none; line-height: 1.7; text-align: left;
    }
    .ok-box  { background: #e8f5ec; color: #1a5e2a; border: 1px solid #9dd4ae; }
    .err-box { background: #fde8e8; color: #8b1a1a; border: 1px solid #f0a9a9; }
    .dl-btn {
      display: inline-block; margin-top: 13px;
      background: #1a5e2a; color: #fff;
      padding: 11px 26px; border-radius: 10px;
      text-decoration: none; font-weight: 800; font-size: 15px;
      transition: background .2s;
    }
    .dl-btn:hover { background: #134820; }

    /* ── футер ── */
    .footer {
      margin-top: 18px; font-size: 11px; color: #bbb; text-align: center;
    }
  </style>
</head>
<body>

  <!-- Статус-бар: актуальность данных -->
  <div class="statusbar">
    <span><span class="pulse"></span><span class="label">Строй-Робот 63</span> &nbsp;·&nbsp; автономный режим</span>
    <span class="ts">
      {% if last_run %}
        Последний отчёт: <b>{{ last_run }}</b>
      {% else %}
        Отчёт ещё не создавался
      {% endif %}
    </span>
  </div>

  <div class="card">
    <div class="icon">🏗️</div>
    <h1>Строй-Робот: Снабжение</h1>
    <p class="desc">
      Робот сам находит файлы по всему серверу,<br>
      очищает данные и объединяет их за один клик.
    </p>

    <div class="files">
      <div class="files-title">📡 Сканирование системы</div>
      {{ file_rows | safe }}
    </div>

    <button class="btn" id="btn" onclick="generate()">СГЕНЕРИРОВАТЬ ОТЧЕТ</button>
    <div id="result"></div>

    <div class="footer">
      Режим: авто-поиск &nbsp;·&nbsp; Глубина сканирования: {{ max_depth }}
    </div>
  </div>

<script>
async function generate() {
  const btn = document.getElementById('btn');
  const box = document.getElementById('result');
  btn.disabled = true;
  btn.textContent = '⏳ Сканирую и обрабатываю...';
  box.style.display = 'none';
  try {
    const r = await fetch('/generate', { method: 'POST' });
    const d = await r.json();
    box.style.display = 'block';
    if (d.ok) {
      box.className = 'ok-box';
      box.innerHTML = '<b>✅ ' + d.msg + '</b>' +
        '<br><a class="dl-btn" href="/download">⬇️ Скачать FINAL_OTCHET.xlsx</a>';
      // Обновляем статус-бар без перезагрузки
      document.querySelector('.ts').innerHTML =
        'Последний отчёт: <b>' + d.ts + '</b>';
    } else {
      box.className = 'err-box';
      box.textContent = '❌ ' + d.msg;
    }
  } catch(e) {
    box.style.display = 'block';
    box.className = 'err-box';
    box.textContent = '❌ Ошибка сети: ' + e.message;
  }
  btn.disabled = false;
  btn.textContent = 'СГЕНЕРИРОВАТЬ ОТЧЕТ';
}
</script>
</body>
</html>
"""

# Кешируем время последнего успешного отчёта
_last_run_ts: str = ""


def _ts_to_moscow(dt: datetime.datetime) -> str:
    """Форматирует время в читаемый вид (UTC+3 Москва)."""
    moscow = dt + datetime.timedelta(hours=3)
    return moscow.strftime("%d.%m.%Y  %H:%M МСК")


@app.route("/")
def index():
    files = find_files()

    def row(label: str, path: str | None) -> str:
        if path:
            fname = os.path.basename(path)
            return (
                f'<div class="file-row">'
                f'<span class="dot ok"></span>'
                f'<div><div class="name">{label}</div>'
                f'<div class="path">✔ Найден: {fname}</div></div></div>'
            )
        return (
            f'<div class="file-row">'
            f'<span class="dot err"></span>'
            f'<div><div class="name">{label}</div>'
            f'<div class="path">⏳ Ожидаю загрузки файлов для анализа</div></div></div>'
        )

    rows = row("База Самары", files["samara"]) + row("ТОП-20 материалов", files["top20"])
    return render_template_string(
        PAGE,
        file_rows=rows,
        last_run=_last_run_ts,
        max_depth=MAX_SEARCH_DEPTH,
    )


@app.route("/generate", methods=["POST"])
def generate():
    global _last_run_ts
    files = find_files()

    missing = [label for label, key in [("База Самары", "samara"), ("ТОП-20 материалов", "top20")]
               if not files[key]]
    if missing:
        return jsonify({
            "ok": False,
            "msg": "Ожидаю загрузки файлов для анализа. Не найдено: " + ", ".join(missing) +
                   ". Загрузите файлы в папку uploads и повторите попытку.",
        })

    try:
        df_base = pd.read_excel(files["samara"])
        df_top  = pd.read_excel(files["top20"])

        result = smart_merge(df_top, df_base)
        result.to_excel(OUTPUT_PATH, index=False)

        now = datetime.datetime.utcnow()
        _last_run_ts = _ts_to_moscow(now)

        return jsonify({
            "ok":  True,
            "ts":  _last_run_ts,
            "msg": f"Готово! Строк: {len(result)}, колонок: {len(result.columns)}. Файл сохранён.",
        })
    except Exception as e:
        return jsonify({"ok": False, "msg": str(e)})


@app.route("/download")
def download():
    if not os.path.exists(OUTPUT_PATH):
        return "Сначала нажмите «СГЕНЕРИРОВАТЬ ОТЧЕТ».", 404
    return send_file(OUTPUT_PATH, as_attachment=True, download_name=OUTPUT_FILENAME)


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=PORT)
